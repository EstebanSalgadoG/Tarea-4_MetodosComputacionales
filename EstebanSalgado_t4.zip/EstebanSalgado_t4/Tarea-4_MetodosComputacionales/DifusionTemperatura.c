#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void difusion_caso1_fijas(int i,int j,int t,int suma,float dx,float dy,float v,float dt,int espacio,int tiempo,float alfa, float beta)
{
  float dif[espacio+1][espacio+1];
   /*Se establecen las condiciones iniciales*/
  for(i=1;i<espacio;i++){
    for(j=1;j<espacio;j++){
      dif[i][j]=50;
    }
  }
  for(i=21;i<32;i++){
    for(j=41;j<62;j++){
      dif[i][j]=100;
    }
  }
  for(t=0;t<tiempo;t++){
    for(i=1;i<espacio-2;i++){
      dif[i][0]=50;
      dif[i][espacio]=50;
      dif[0][i]=50;
      dif[espacio][i]=50;
      for(j=1;j<espacio-2;j++){
	if(t==0){
	  printf("1, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	else if(t==100){
	  printf("1, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	else if(t==2500){
	  printf("1, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	dif[i][j]=alfa*(dif[i+1][j]+dif[i-1][j]) + beta*(dif[i][j+1]+dif[i][j-1]) + (1-2*alfa-2*beta)*dif[i][j];
      }      
    }
  }
}  

void difusion_caso1_periodicas(int i,int j,int t,int suma,float dx,float dy,float v,float dt,int espacio,int tiempo,float alfa, float beta)
{
  float dif[espacio+1][espacio+1];
   /*Se establecen las condiciones iniciales*/
  for(i=1;i<espacio;i++){
    for(j=1;j<espacio;j++){
      dif[i][j]=50;
    }
  }
  for(i=21;i<32;i++){
    for(j=41;j<62;j++){
      dif[i][j]=100;
    }
  }
  for(t=0;t<tiempo;t++){
    for(i=1;i<espacio-2;i++){
      dif[i][0]=dif[i][espacio-1];
      dif[i][espacio]=dif[i][1];
      dif[0][i]=dif[espacio-1][i];
      dif[espacio][i]=dif[1][i];
      for(j=1;j<espacio-2;j++){
	if(t==0){
	  printf("2, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	else if(t==100){
	  printf("2, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	else if(t==2500){
	  printf("2, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	dif[i][j]=alfa*(dif[i+1][j]+dif[i-1][j]) + beta*(dif[i][j+1]+dif[i][j-1]) + (1-2*alfa-2*beta)*dif[i][j];
      }      
    }
  }
} 

void difusion_caso1_abiertas(int i,int j,int t,int suma,float dx,float dy,float v,float dt,int espacio,int tiempo,float alfa, float beta)
{
  float dif[espacio+1][espacio+1];
   /*Se establecen las condiciones iniciales*/
  for(i=1;i<espacio;i++){
    for(j=1;j<espacio;j++){
      dif[i][j]=50;
    }
  }
  for(i=21;i<32;i++){
    for(j=41;j<62;j++){
      dif[i][j]=100;
    }
  }
  for(t=0;t<tiempo;t++){
    for(i=1;i<espacio-2;i++){
      dif[i][0]=dif[i][1];
      dif[i][espacio]=dif[i][espacio-1];
      dif[0][i]=dif[1][i];
      dif[espacio][i]=dif[espacio-1][i];
      for(j=1;j<espacio-2;j++){
	if(t==0){
	  printf("3, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	else if(t==100){
	  printf("3, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	else if(t==2500){
	  printf("3, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	dif[i][j]=alfa*(dif[i+1][j]+dif[i-1][j]) + beta*(dif[i][j+1]+dif[i][j-1]) + (1-2*alfa-2*beta)*dif[i][j];
      }      
    }
  }
} 

void difusion_caso2_fijas(int i,int j,int t,int suma,float dx,float dy,float v,float dt,int espacio,int tiempo,float alfa, float beta)
{
  float dif[espacio+1][espacio+1];
   /*Se establecen las condiciones iniciales*/
  for(i=1;i<espacio;i++){
    for(j=1;j<espacio;j++){
      dif[i][j]=50;
    }
  }
  for(i=21;i<32;i++){
    for(j=41;j<62;j++){
      dif[i][j]=100;
    }
  }
  for(t=0;t<tiempo;t++){
    for(i=21;i<32;i++){
      for(j=41;j<62;j++){
	dif[i][j]=100;
      }
    }
    for(i=1;i<espacio-2;i++){
      dif[i][0]=50;
      dif[i][espacio]=50;
      dif[0][i]=50;
      dif[espacio][i]=50;
      for(j=1;j<espacio-2;j++){
	if(t==0){
	  printf("4, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	else if(t==100){
	  printf("4, %d ,%d ,%d, %f\n",t,i,j,dif[i][j]);
	}
	else if(t==2500){
	  printf("4, %d ,%d ,%d, %f\n",t,i,j,dif[i][j]);
	}
	dif[i][j]=alfa*(dif[i+1][j]+dif[i-1][j]) + beta*(dif[i][j+1]+dif[i][j-1]) + (1-2*alfa-2*beta)*dif[i][j];
      }      
    }
  }
}  

void difusion_caso2_periodicas(int i,int j,int t,int suma,float dx,float dy,float v,float dt,int espacio,int tiempo,float alfa, float beta)
{
  float dif[espacio+1][espacio+1];
   /*Se establecen las condiciones iniciales*/
  for(i=1;i<espacio;i++){
    for(j=1;j<espacio;j++){
      dif[i][j]=50;
    }
  }
  for(i=21;i<32;i++){
    for(j=41;j<62;j++){
      dif[i][j]=100;
    }
  }
  for(t=0;t<tiempo;t++){
    for(i=21;i<32;i++){
      for(j=41;j<62;j++){
	dif[i][j]=100;
      }
    }
    for(i=1;i<espacio-2;i++){
      dif[i][0]=dif[i][espacio-1];
      dif[i][espacio]=dif[i][1];
      dif[0][i]=dif[espacio-1][i];
      dif[espacio][i]=dif[1][i];
      for(j=1;j<espacio-2;j++){
	if(t==0){
	  printf("5, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	else if(t==100){
	  printf("5, %d ,%d ,%d, %f\n",t,i,j,dif[i][j]);
	}
	else if(t==2500){
	  printf("5, %d ,%d ,%d, %f\n",t,i,j,dif[i][j]);
	}
	dif[i][j]=alfa*(dif[i+1][j]+dif[i-1][j]) + beta*(dif[i][j+1]+dif[i][j-1]) + (1-2*alfa-2*beta)*dif[i][j];
      }      
    }
  }
} 

void difusion_caso2_abiertas(int i,int j,int t,int suma,float dx,float dy,float v,float dt,int espacio,int tiempo,float alfa, float beta)
{
  float dif[espacio+1][espacio+1];
   /*Se establecen las condiciones iniciales*/
  for(i=1;i<espacio;i++){
    for(j=1;j<espacio;j++){
      dif[i][j]=50;
    }
  }
  for(i=21;i<32;i++){
    for(j=41;j<62;j++){
      dif[i][j]=100;
    }
  }
  for(t=0;t<tiempo;t++){
    for(i=21;i<32;i++){
      for(j=41;j<62;j++){
	dif[i][j]=100;
      }
    }
    for(i=1;i<espacio-2;i++){
      dif[i][0]=dif[i][1];
      dif[i][espacio]=dif[i][espacio-1];
      dif[0][i]=dif[1][i];
      dif[espacio][i]=dif[espacio-1][i];
      for(j=1;j<espacio-2;j++){
	if(t==0){
	  printf("6, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	else if(t==100){
	  printf("6, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	else if(t==2500){
	  printf("6, %d ,%d ,%d, %f\n",t,i,j, dif[i][j]);
	}
	dif[i][j]=alfa*(dif[i+1][j]+dif[i-1][j]) + beta*(dif[i][j+1]+dif[i][j-1]) + (1-2*alfa-2*beta)*dif[i][j];
      }      
    }
  }
} 

int main(){
  int i;
  int j;
  int t;
  int l;
  float suma=0;
  float dx=0.01;
  float dy=0.01;
  float v=0.0001;
  float dt=(dx*dy)/(4*v);
  int espacio=100; /*1/dx*/
  int tiempo=10001; /*2500/dt*/
  float alfa=(v*dt)/(dx*dx);
  float beta=(v*dt)/(dy*dy);
  difusion_caso1_fijas(i,j,t,suma,dx,dy,v,dt,espacio,tiempo,alfa,beta);
  difusion_caso1_periodicas(i,j,t,suma,dx,dy,v,dt,espacio,tiempo,alfa,beta);
  difusion_caso1_abiertas(i,j,t,suma,dx,dy,v,dt,espacio,tiempo,alfa,beta);
  difusion_caso2_fijas(i,j,t,suma,dx,dy,v,dt,espacio,tiempo,alfa,beta);
  difusion_caso2_periodicas(i,j,t,suma,dx,dy,v,dt,espacio,tiempo,alfa,beta);
  difusion_caso2_abiertas(i,j,t,suma,dx,dy,v,dt,espacio,tiempo,alfa,beta);

  return 0;
}