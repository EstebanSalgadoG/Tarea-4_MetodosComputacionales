import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d

datos=np.genfromtxt("DifusionTemperatura.txt", delimiter=",")
n=9409

#CASO1, condiciones abiertas
T0_C1_abiertas=datos[0:9408,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T0_C1_abiertas[:,0],T0_C1_abiertas[:,1],T0_C1_abiertas[:,2])
plt.savefig("Tiempo1_Caso1_Abiertas",format="jpg")
plt.close()

T100_C1_abiertas=datos[9409:18817,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T100_C1_abiertas[:,0],T100_C1_abiertas[:,1],T100_C1_abiertas[:,2])
plt.savefig("Tiempo2_Caso1_Abiertas ",format="jpg")
plt.close()

T2500_C1_abiertas=datos[18818:28226,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T2500_C1_abiertas[:,0],T2500_C1_abiertas[:,1],T2500_C1_abiertas[:,2])
plt.savefig("Tiempo3_Caso1_Abiertas",format="jpg")
plt.close()

#CASO1, condiciones periodicas
T0_C1_periodicas=datos[28227:37635,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T0_C1_periodicas[:,0],T0_C1_periodicas[:,1],T0_C1_periodicas[:,2])
plt.savefig("Tiempo1_Caso1_Periodicas",format="jpg")
plt.close()

T100_C1_periodicas=datos[37636:47044,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T100_C1_periodicas[:,0],T100_C1_periodicas[:,1],T100_C1_periodicas[:,2])
plt.savefig("Tiempo2_Caso1_Periodicas",format="jpg")
plt.close()

T2500_C1_periodicas=datos[47045:56453,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T2500_C1_periodicas[:,0],T2500_C1_periodicas[:,1],T2500_C1_periodicas[:,2])
plt.savefig("Tiempo3_Caso1_Periodicas",format="jpg")
plt.close()

#CASO1 condiciones fijas
T0_C1_fijas=datos[56454:65862,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T0_C1_fijas[:,0],T0_C1_fijas[:,1],T0_C1_fijas[:,2])
plt.savefig("Tiempo1_Caso1_Fijas",format="jpg")
plt.close()

T100_C1_fijas=datos[65863:75271,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T100_C1_fijas[:,0],T100_C1_fijas[:,1],T100_C1_fijas[:,2])
plt.savefig("Tiempo2_Caso1_Fijas",format="jpg")
plt.close()

T2500_C1_fijas=datos[75272:84680,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T2500_C1_fijas[:,0],T2500_C1_fijas[:,1],T2500_C1_fijas[:,2])
plt.savefig("Tiempo3_Caso 1_Fijas",format="jpg")
plt.close()

#--------------------------------------------------------------------------------------------------------------------------------------------

#CASO2 condiciones abiertas
T0_C2_abiertas=datos[84681:94089,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T0_C2_abiertas[:,0],T0_C2_abiertas[:,1],T0_C2_abiertas[:,2])
plt.savefig("Tiempo1_Caso2_Abiertas",format="jpg")
plt.close()

T100_C2_abiertas=datos[94090:103498,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T100_C2_abiertas[:,0],T100_C2_abiertas[:,1],T100_C2_abiertas[:,2])
plt.savefig("Tiempo2_Caso2_Abiertas",format="jpg")
plt.close()

T2500_C2_abiertas=datos[103499:112907,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T2500_C2_abiertas[:,0],T2500_C2_abiertas[:,1],T2500_C2_abiertas[:,2])
plt.savefig("Tiempo3_Caso2_Abiertas",format="jpg")
plt.close()

#CASO2 condiciones periodicas
T0_C2_periodicas=datos[112908:122316,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T0_C2_periodicas[:,0],T0_C2_periodicas[:,1],T0_C2_periodicas[:,2])
plt.savefig("Tiempo1_Caso2_Periodicas",format="jpg")
plt.close()

T100_C2_periodicas=datos[122317:131725,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T100_C2_periodicas[:,0],T100_C2_periodicas[:,1],T100_C2_periodicas[:,2])
plt.savefig("Tiempo2_Caso2_Periodicas",format="jpg")
plt.close()

T2500_C2_periodicas=datos[131726:141134,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T2500_C2_periodicas[:,0],T2500_C2_periodicas[:,1],T2500_C2_periodicas[:,2])
plt.savefig("Tiempo3_Caso2_Periodicas",format="jpg")
plt.close()

#CASO2 condiciones fijas
T0_C2_fijas=datos[141135:150543,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T0_C2_fijas[:,0],T0_C2_fijas[:,1],T0_C2_fijas[:,2])
plt.savefig("Tiempo1_Caso2_Fijas",format="jpg")
plt.close()

T100_C2_fijas=datos[150544:159952,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T100_C2_fijas[:,0],T100_C2_fijas[:,1],T100_C2_fijas[:,2])
plt.savefig("Tiempo2_Caso2_Fijas",format="jpg")
plt.close()

T2500_C2_fijas=datos[159953:169361,2:5]
fig=plt.figure()
ax=fig.add_subplot(111, projection="3d")
ax.plot_wireframe(T2500_C2_fijas[:,0],T2500_C2_fijas[:,1],T2500_C2_fijas[:,2])
plt.savefig("Tiempo3_Caso2_Fijas",format="jpg")
plt.close()




